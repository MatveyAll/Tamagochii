package com.example.tamagochi;

public class LivePriority {
    int hungerPr = 0;
    int boringPr = 0;
    int happyPr = 0;
    int tiredPr = 0;
    int sleepPr = 0;
    int allPr = hungerPr + boringPr + happyPr + tiredPr + sleepPr;

    int hours = 0,minutes = 0,seconds = 0;
    int whileTime = 1;

    int currentHours;
    int currentMinutes;
    int currentSeconds;

}
