package com.example.tamagochi;

public class Image {
    int imageId;

    public Image(int imageId) {
        this.imageId = imageId;
    }
}
