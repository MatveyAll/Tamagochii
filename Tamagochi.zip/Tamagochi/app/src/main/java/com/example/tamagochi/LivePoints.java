package com.example.tamagochi;

public class LivePoints {
    int hpWhileAlive = 1;
    int hpWhileBoring = 1;
    int hpWhileHappy = 1;
    int hpWhileTired = 1;
    int hpWhileSleep = 1;
    int speedH = 1000;
    int speedB = 1000;
    int speedHap = 1000;
    int speedT = 1000;
    int wasBored = 0;
    int wasSad = 0;
    double debufH = 0.9;
    double debufT = 0.9;
    public int hungerBar = 100;
    public int boringBar = 0;
    public int happyBar = 100;
    public int tiredBar = 100;

}
